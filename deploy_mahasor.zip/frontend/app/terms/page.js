export default function TermsPage() {
  return (
    <div className="container" style={{ padding: '60px 20px', maxWidth: 800 }}>
      <h1 style={{ fontSize: 36, fontWeight: 800, marginBottom: 20 }}>Terms of Service</h1>
      <p style={{ color: 'var(--text-light)', marginBottom: 40, lineHeight: 1.6 }}>
        Last updated: {new Date().toLocaleDateString()}
      </p>

      <div className="card" style={{ marginBottom: 24 }}>
        <h3 style={{ fontSize: 20, marginBottom: 12 }}>1. Acceptance of Terms</h3>
        <p style={{ color: 'var(--text-light)' }}>
          By accessing and using Mahasor Journey, provided by Soreng Holidays Private Limited, you agree to comply with and be bound by these terms. If you do not agree, please do not use our services.
        </p>
      </div>

      <div className="card" style={{ marginBottom: 24 }}>
        <h3 style={{ fontSize: 20, marginBottom: 12 }}>2. User Responsibilities</h3>
        <p style={{ color: 'var(--text-light)' }}>
          You agree to provide accurate information when making bookings. You are responsible for all activities that occur under your account. Any fraudulent or abusive bookings may result in immediate account suspension.
        </p>
      </div>

      <div className="card" style={{ marginBottom: 24 }}>
        <h3 style={{ fontSize: 20, marginBottom: 12 }}>3. Refunds and Cancellations</h3>
        <p style={{ color: 'var(--text-light)' }}>
          Cancellations are subject to the policies of the specific airline, hotel, or bus operator. Mahasor Journey will process refunds according to these third-party policies. A service fee may be deducted. Refunds typically reflect in the original payment method within 5-7 business days.
        </p>
      </div>

      <div className="card" style={{ marginBottom: 24 }}>
        <h3 style={{ fontSize: 20, marginBottom: 12 }}>4. Limitation of Liability</h3>
        <p style={{ color: 'var(--text-light)' }}>
          Soreng Holidays Private Limited acts solely as an intermediary between users and travel service providers. We are not liable for any delays, cancellations, or damages caused by third-party providers.
        </p>
      </div>
    </div>
  );
}
